<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;

class UsersController extends AppController
{

    public function beforeFilter(Event $event)
    {
        parent::beforeFilter($event);
        $this->Auth->allow('login');
    }
    public function index()
    {
		$Users = $this->Users->find('all')->where(['Users.type'=>'Owner'])->toArray();
		$jobsTable = TableRegistry::get('Jobs');
		foreach ($Users as $key => $value) {
			$Users[$key]['jobs_completed']=$jobsTable->find('all')->where(['user_id'=>$value['id'],'status'=>'Completed'])->count();
			$Users[$key]['jobs_cancelled']=$jobsTable->find('all')->where(['user_id'=>$value['id'],'status'=>'Cancelled'])->count();
			$Users[$key]['jobs_posted']=$jobsTable->find('all')->where(['user_id'=>$value['id']])->count();
		}
		$menu = ["menu"=>"homeowner","menu_type"=>"manpower","admin"=>$this->Auth->user()];
		$this->set(compact('Users','menu'));
        $this->set('_serialize', ['Users','menu']);
    }

    public function contractors()
    {
		$Users = $this->Users->find('all')->where(['Users.type'=>'Contractor'])->toArray();
		$jobsTable = TableRegistry::get('Jobs');
		foreach ($Users as $key => $value) {
			$Users[$key]['jobs_completed']=$jobsTable->find('all')->where(['user_id'=>$value['id'],'status'=>'Completed'])->count();
			$Users[$key]['jobs_cancelled']=$jobsTable->find('all')->where(['user_id'=>$value['id'],'status'=>'Cancelled'])->count();
			$Users[$key]['jobs_posted']=$jobsTable->find('all')->where(['user_id'=>$value['id']])->count();
		}
		$menu = ["menu"=>"contractors","menu_type"=>"manpower","admin"=>$this->Auth->user()];
		$this->set(compact('Users','menu'));
        $this->set('_serialize', ['Users','menu']);
    }

	public function premiumContractors()
    {
		$Users = $this->Users->find('all')->where(['Users.type'=>'PremiumContractor'])->toArray();
		$jobsTable = TableRegistry::get('Jobs');
		foreach ($Users as $key => $value) {
			$Users[$key]['jobs_completed']=$jobsTable->find('all')->where(['user_id'=>$value['id'],'status'=>'Completed'])->count();
			$Users[$key]['jobs_cancelled']=$jobsTable->find('all')->where(['user_id'=>$value['id'],'status'=>'Cancelled'])->count();
			$Users[$key]['jobs_posted']=$jobsTable->find('all')->where(['user_id'=>$value['id']])->count();
		}
		$menu = ["menu"=>"premium_contractors","menu_type"=>"manpower","admin"=>$this->Auth->user()];
		$this->set(compact('Users','menu'));
        $this->set('_serialize', ['Users','menu']);
    }

    public function overview(){
		$jobsTable = TableRegistry::get('Jobs');
		$Query =  $jobsTable->find('all');
		$Query->select([
		  	'id','type',
		  	'count' => $Query->func()->count('*')
		])
		->group(['Jobs.type']);
        $Users['type'] = [
            ];
        $totalJobs = 0;
		foreach ($Query as $key => $value) {
			$Users['type'][$value['type']] = $value['count'];
			$totalJobs += $value['count'];
		}
        // 		echo $totalJobs;
        // 		pr($Users);

		$Users['type']['Replacement'] = isset($Users['type']['Replacement'])?($Users['type']['Replacement']/$totalJobs*100):0;
		$Users['type']['Plumbing'] = isset($Users['type']['Plumbing'])?($Users['type']['Plumbing']/$totalJobs*100):0;
		$Users['type']['Electrical'] = isset($Users['type']['Electrical'])?($Users['type']['Electrical']/$totalJobs*100):0;
		$Users['type']['Maintenance'] = isset($Users['type']['Maintenance'])?($Users['type']['Maintenance']/$totalJobs*100):0;
		$Users['type']['Others'] = isset($Users['type']['Others'])?($Users['type']['Others']/$totalJobs*100):0;

		// pr($Users);
		// exit;
		$menu = ["menu"=>"","menu_type"=>"overview","admin"=>$this->Auth->user()];
		$this->set(compact('Users','menu'));
        $this->set('_serialize', ['Users','menu']);
	}

	public function deleteOwner($id=null){
		$user = $this->Users->get($id);
		if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again..'));
        }
		return $this->redirect(['action' => 'index']);
	}

	public function deletePremium($id=null){
		$user = $this->Users->get($id);
		if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again..'));
        }
		return $this->redirect(['action' => 'premiumContractors']);
	}

	public function deleteContractors($id=null){
		$user = $this->Users->get($id);
		if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again..'));
        }
		return $this->redirect(['action' => 'contractors']);
	}

    public function login()
    {
        if($this->isAuthorized()){
          return $this->redirect(['action' => 'index']);
        }
        $this->viewBuilder()->layout('login');
        $user = "";
        if ($this->request->is(['patch', 'post', 'put'])) {
            $data = $this->request->data;
			//pr($data); exit;
            $user = $this->Auth->identify();
			// pr($user);
			// exit;
            if ($user) {
                $this->Auth->setUser($user);
                $this->Flash->success(__('Logged in successfully.'));
                return $this->redirect(['controller'=>"Users",'action' => 'index']);
            }
            else {
                $this->Flash->error(__('Please enter valied email and password.'));
            }
        }
        $this->set(compact('user'));
        $this->set('_serialize', ['user']);
    }

    public function logout()
    {
        $this->Auth->logout();
        $this->Flash->success(__('Logout successfully.'));
        return $this->redirect(['action' => 'login']);
    }

}
